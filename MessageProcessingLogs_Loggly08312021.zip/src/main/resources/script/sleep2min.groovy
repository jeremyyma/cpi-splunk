/*
Delay Message for 120 seconds
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    map = message.getProperties();
    def strDelay =map.get("delayTimeMS");
    Integer delayTimeMS = strDelay.toInteger();
    
    sleep(delayTimeMS);
    
    //def body = message.getBody();
    return message;

}