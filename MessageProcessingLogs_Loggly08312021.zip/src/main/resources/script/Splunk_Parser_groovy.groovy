import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String);
    
    if (body !=null | body.getBytes().length>250)
    try{
        
        body = message.getBody(java.io.Reader);
      
        def inputJSON = new groovy.json.JsonSlurper().parse(body); 
        def builder = new JsonBuilder(inputJSON.MessageProcessingLog);

        //builder = builder.unique();  // remove duplicates
        builder = builder.toString().replace('},{"Status"', '} \n {"Status"').replace('["','"').replace('"]','"'); //replace , w. newline for loggly
        builder = builder.toString().replace('},{"Sender"', '} \n {"Sender"').replace('["','"').replace('"]','"'); //replace , w. newline for loggly
        builder = builder.substring(1, builder.length() - 1); //remove begin and end [ ] otherwise this is treaded as single event
               //builder = builder.toString().replace('},{"Status"', '} \n {"Status"'); //raw 
               
               //builder = builder.toString().replace("},{", "}, \n {"); // maybe for XML parser but effects splunk
        message.setBody(builder.toString());
               //println( builder.toString() );//testing
        message.setProperty ("noMPLData", "0");
        return message;
    }
    catch(Exception e)
    {
        message.setProperty ("noMPLData", "1");
        return message;

    }
    else
    {
         message.setProperty ("noMPLData", "1");
         return message;
    }
    
}