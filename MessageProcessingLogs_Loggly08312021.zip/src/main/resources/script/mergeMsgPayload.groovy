import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import groovy.json.JsonSlurper;
import java.util.HashMap;
import java.util.Map;


def Message processData(Message message) {

    //Tranform plain/txt to XML and format to XML entities.
    def String MessageProcessingLogErrorInformations = "<Status>FAILED</Status><ErrorInfo>"  + groovy.xml.XmlUtil.escapeXml(message.getBody(java.lang.String)) + "</ErrorInfo>";
    //Headers
    def map = message.getProperties();
    String MsgPayload = map.get("MsgPayload");
    
    //merge errorInfo to existing Payload
    MsgPayload = MsgPayload.replace("<Status>FAILED</Status>", MessageProcessingLogErrorInformations )

    message.setBody(MsgPayload);
    return message;
}