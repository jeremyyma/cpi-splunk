import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    //Body
    /** This code has been moved to Javascript file
    def body = message.getBody(java.lang.String) as String
    //Check if message data type is JSON
    try{
            new JsonSlurper().parseText(body);
    }catch(Exception e){
        //Set data type to raw
        message.setHeader("splunk_datatype", "raw");
    }
    */
    //Get splunk security HEC token
    String token = "";
    def properties = message.getProperties();
    def key = properties.get("SECURITY_ID");
    
    def service = ITApiFactory.getApi(SecureStoreService.class, null);
    def credential = service.getUserCredential(key); 
    if (credential == null){
        throw new IllegalStateException("No credential found for alias '"+key+"'");             
    } else {
        token = new String(credential.getPassword());
    }
    
    //Set token to the header
    message.setHeader("Authorization", "Splunk "+token);
    return message;
}